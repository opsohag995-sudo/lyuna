import { useState } from 'react';
import { Heart, Mail, Download, Send } from 'lucide-react';

type ViewMode = 'home' | 'generated';

export default function App() {
  const [text, setText] = useState('');
  const [generatedContent, setGeneratedContent] = useState('');
  const [viewMode, setViewMode] = useState<ViewMode>('home');

  const handleGenerate = () => {
    if (text.trim()) {
      setGeneratedContent(text);
      setViewMode('generated');
      // Auto-download HTML file
      generateAndDownloadFile(text);
    }
  };

  const generateAndDownloadFile = (content: string) => {
    const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lyuna Bro - Special Letter</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .container {
            position: relative;
            width: 100%;
            max-width: 600px;
            perspective: 1000px;
        }
        
        .card-wrapper {
            position: relative;
            width: 100%;
            height: 400px;
            cursor: pointer;
            transform-style: preserve-3d;
            transition: transform 0.8s ease-out;
        }
        
        .card-wrapper.flipped {
            transform: rotateY(180deg);
        }
        
        .card-face {
            position: absolute;
            width: 100%;
            height: 100%;
            backface-visibility: hidden;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            padding: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .card-front {
            background: linear-gradient(135deg, #ffa751 0%, #ffe259 100%);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 20px;
        }
        
        .heart-icon {
            font-size: 80px;
            animation: heartbeat 1.5s ease-in-out infinite;
        }
        
        @keyframes heartbeat {
            0%, 100% { transform: scale(1); }
            25% { transform: scale(1.1); }
            50% { transform: scale(1.2); }
        }
        
        .tap-text {
            font-size: 24px;
            font-weight: 600;
            color: white;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.2);
            animation: pulse 2s ease-in-out infinite;
        }
        
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.7; }
        }
        
        .card-back {
            background: white;
            transform: rotateY(180deg);
            overflow-y: auto;
        }
        
        .letter-content {
            position: relative;
        }
        
        .letter-header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 3px solid #667eea;
            padding-bottom: 20px;
        }
        
        .letter-header h1 {
            color: #667eea;
            font-size: 32px;
            margin-bottom: 10px;
            font-family: 'Georgia', serif;
        }
        
        .letter-header p {
            color: #999;
            font-size: 12px;
            font-style: italic;
        }
        
        .letter-body {
            color: #333;
            line-height: 1.8;
            font-size: 16px;
            white-space: pre-wrap;
            word-wrap: break-word;
            font-family: 'Georgia', serif;
            text-align: justify;
        }
        
        .letter-footer {
            margin-top: 40px;
            text-align: right;
            color: #667eea;
            font-size: 18px;
            font-family: 'Georgia', serif;
        }
        
        .decorative-line {
            width: 100px;
            height: 2px;
            background: linear-gradient(to right, transparent, #667eea, transparent);
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card-wrapper" id="cardWrapper">
            <!-- Front of card -->
            <div class="card-face card-front">
                <div class="heart-icon">💖</div>
                <div class="tap-text">Click to Open</div>
            </div>
            
            <!-- Back of card -->
            <div class="card-face card-back">
                <div class="letter-content">
                    <div class="letter-header">
                        <h1>✨ Special Letter ✨</h1>
                        <p>From: Lyuna Bro</p>
                    </div>
                    <div class="decorative-line"></div>
                    <div class="letter-body">${content}</div>
                    <div class="letter-footer">
                        <div class="decorative-line"></div>
                        <p>💝 Made with Love 💝</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        const cardWrapper = document.getElementById('cardWrapper');
        let isFlipped = false;
        
        cardWrapper.addEventListener('click', function() {
            isFlipped = !isFlipped;
            if (isFlipped) {
                cardWrapper.classList.add('flipped');
            } else {
                cardWrapper.classList.remove('flipped');
            }
        });
    </script>
</body>
</html>`;

    const blob = new Blob([htmlContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'lyuna-bro-letter.html';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleDownload = () => {
    generateAndDownloadFile(generatedContent);
  };

  if (viewMode === 'home') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-600 via-pink-500 to-red-500 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="inline-block mb-4">
              <div className="relative w-16 h-16 flex items-center justify-center">
                <div className="absolute inset-0 bg-white rounded-full blur-lg opacity-50"></div>
                <Heart size={64} className="text-white relative z-10 fill-white" />
              </div>
            </div>
            <h1 className="text-5xl font-bold text-white mb-2" style={{ fontFamily: 'Georgia, serif' }}>
              Lyuna Bro
            </h1>
            <p className="text-white text-lg opacity-90">Premium Letter Generator</p>
          </div>

          {/* Main Card */}
          <div className="bg-white rounded-3xl shadow-2xl p-8 backdrop-blur-md">
            <div className="mb-6">
              <label className="block text-gray-700 font-bold mb-2 text-lg">
                💌 আপনার প্রিয় মানুষের জন্য লেখুন
              </label>
              <p className="text-gray-500 text-sm mb-4">আপনার হৃদয়ের কথা শেয়ার করুন...</p>
              <textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="এখানে আপনার বার্তা লেখুন..."
                className="w-full h-64 p-4 border-2 border-purple-200 rounded-xl focus:outline-none focus:border-purple-500 resize-none bg-purple-50 text-gray-800"
              />
            </div>

            {/* Button Group */}
            <div className="flex gap-4">
              <button
                onClick={handleGenerate}
                disabled={!text.trim()}
                className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold py-3 px-6 rounded-xl hover:shadow-lg transform hover:scale-105 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                <Send size={20} />
                Generate
              </button>
            </div>

            {/* Features */}
            <div className="mt-8 pt-6 border-t-2 border-purple-100">
              <h3 className="text-gray-700 font-bold mb-4">✨ বৈশিষ্ট্য:</h3>
              <ul className="space-y-2 text-sm text-gray-600">
                <li className="flex items-center gap-2">
                  <Mail size={16} className="text-purple-500" />
                  <span>প্রিমিয়াম চিঠির ডিজাইন</span>
                </li>
                <li className="flex items-center gap-2">
                  <Heart size={16} className="text-pink-500" />
                  <span>স্পেশাল ইফেক্ট সহ</span>
                </li>
                <li className="flex items-center gap-2">
                  <Download size={16} className="text-blue-500" />
                  <span>তাৎক্ষণিক ডাউনলোড</span>
                </li>
              </ul>
            </div>
          </div>

          {/* Footer */}
          <p className="text-center text-white text-sm mt-8 opacity-80">
            Made with 💖 by Lyuna Bro
          </p>
        </div>
      </div>
    );
  }

  // Generated view
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-pink-500 to-red-500 flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        {/* Back Button */}
        <button
          onClick={() => {
            setViewMode('home');
            setText('');
            setGeneratedContent('');
          }}
          className="mb-6 text-white font-bold flex items-center gap-2 hover:opacity-80 transition"
        >
          ← ফিরে যান
        </button>

        {/* Success Message */}
        <div className="bg-white rounded-3xl shadow-2xl p-8 mb-6">
          <div className="text-center mb-6">
            <div className="inline-block mb-4">
              <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center animate-bounce">
                <Heart size={32} className="text-white fill-white" />
              </div>
            </div>
            <h2 className="text-3xl font-bold text-gray-800 mb-2">সফল! 🎉</h2>
            <p className="text-gray-600">আপনার চিঠি তৈরি হয়েছে এবং ডাউনলোড হয়েছে!</p>
          </div>

          {/* Generated Content Preview */}
          <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl p-6 mb-6 max-h-64 overflow-y-auto">
            <div className="text-center mb-4">
              <h3 className="text-2xl font-bold text-purple-600 mb-2" style={{ fontFamily: 'Georgia, serif' }}>
                ✨ Special Letter ✨
              </h3>
              <p className="text-gray-500 text-sm">From: Lyuna Bro</p>
            </div>
            <div className="border-t-2 border-purple-300 pt-4 mt-4">
              <p className="text-gray-700 whitespace-pre-wrap text-justify leading-relaxed">
                {generatedContent}
              </p>
            </div>
            <div className="text-center mt-6 text-purple-600 font-semibold">
              💝 Made with Love 💝
            </div>
          </div>

          {/* Download Button */}
          <div className="flex gap-4">
            <button
              onClick={handleDownload}
              className="flex-1 bg-gradient-to-r from-green-500 to-blue-600 text-white font-bold py-3 px-6 rounded-xl hover:shadow-lg transform hover:scale-105 transition flex items-center justify-center gap-2"
            >
              <Download size={20} />
              আবার ডাউনলোড করুন
            </button>
            <button
              onClick={() => {
                setViewMode('home');
                setText('');
                setGeneratedContent('');
              }}
              className="flex-1 bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-3 px-6 rounded-xl transition"
            >
              নতুন চিঠি লিখুন
            </button>
          </div>
        </div>

        {/* Instructions */}
        <div className="bg-white bg-opacity-20 backdrop-blur-md rounded-2xl p-6 text-white">
          <h3 className="font-bold mb-3">📋 নির্দেশনা:</h3>
          <ol className="space-y-2 text-sm">
            <li>1️⃣ ডাউনলোড করা ফাইলটি খুলুন</li>
            <li>2️⃣ হৃদয়ের আইকনে ক্লিক করুন</li>
            <li>3️⃣ আপনার সুন্দর চিঠি দেখুন 💌</li>
          </ol>
        </div>
      </div>
    </div>
  );
}
